package Outdoor.games.minimap.OGM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OgmApplication {

	public static void main(String[] args) {
		SpringApplication.run(OgmApplication.class, args);
	}
}
